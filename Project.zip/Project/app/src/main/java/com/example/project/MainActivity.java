package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TextWatcher {

    TextView tv_text;
    String generatedText, userText;
    SpannableString ss;
    ForegroundColorSpan fcsGreen;
    BackgroundColorSpan bcsRed;
    EditText et_input;
    int tot_index, curr_index, prev_length, mistakeStrike, lastCorrect;
    boolean isCorrect, firstTime, backspace;
    int curWordLength;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_input = findViewById(R.id.input);
        et_input.addTextChangedListener(this);

        tv_text = findViewById(R.id.text);

        generatedText = tv_text.getText().toString();

        ss = new SpannableString(generatedText);

        bcsRed = new BackgroundColorSpan(Color.RED);
        fcsGreen = new ForegroundColorSpan(Color.GREEN);

        tot_index = 0;
        curr_index = 0;
        prev_length = 0;
        mistakeStrike = 0;
        lastCorrect = 0;

        curWordLength = getCurWordLength(generatedText, tot_index);

        isCorrect = true;
        firstTime = true;
        backspace = true;
    }

    public void changeGreen(int index, int length){
        ss.setSpan(fcsGreen, index, index + length + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv_text.setText(ss);
    }

    public void changeRed(int index, int length){
        ss.setSpan(bcsRed, index, index + length + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv_text.setText(ss);
    }


    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }


    @Override
    public void afterTextChanged(Editable editable) {
        userText = editable.toString();
        //if no mistakes
        if(!firstTime && isCorrect && backspace) {
            //if added
            if (userText.length() > prev_length) {
                curr_index++;
                prev_length++;
                //added and true
                if (userText.charAt(curr_index - 1) == generatedText.charAt(tot_index + curr_index - 1)) {
                    lastCorrect = curr_index - 1;
                    changeGreen(tot_index, curr_index - 1);
                    //check if completed word
                    if (curr_index - 1 == curWordLength) {
                        tot_index += curr_index;
                        curr_index = 0;
                        prev_length = 0;
                        mistakeStrike = 0;
                        lastCorrect = 0;
                        curWordLength = getCurWordLength(generatedText, tot_index);
                        backspace = false;
                    }
                } else {
                    //added and false
                    isCorrect = false;
                    mistakeStrike++;
                    if (userText.charAt(0) != generatedText.charAt(tot_index)) {
                        changeRed(tot_index + lastCorrect, mistakeStrike);
                    } else changeRed(tot_index + lastCorrect + 1, mistakeStrike);
                }
            }else { //if deleted
                curr_index--;
                prev_length--;
                lastCorrect = curr_index;
                changeGreen(tot_index, curr_index);
            }
        }
        else if(!isCorrect){
            //if there are mistakes
            //if added
            if(userText.length() > prev_length){
                curr_index++;
                prev_length++;
                mistakeStrike++;
                changeRed(tot_index + lastCorrect, mistakeStrike - 1);
            } else{ //if deleted
                curr_index--;
                prev_length--;
                mistakeStrike--;
                changeRed(tot_index + lastCorrect, mistakeStrike - 1);
            }
        }

        if(firstTime) {
            curr_index++;
            firstTime = false;
            if (userText.charAt(0) == generatedText.charAt(tot_index)) {
                lastCorrect = curr_index;
                changeGreen(tot_index, 0);
            }
            else {
                changeRed(tot_index, 0);
                mistakeStrike++;
                isCorrect = false;
            }
        }

        if(!backspace && userText.charAt(tot_index - 1) == ' ')
        {
            backspace = true;
            editable.clear();
            firstTime = true;
            prev_length++;
        }

        if(mistakeStrike == 0 && !isCorrect) {
            if(curr_index == 0)
            {
                isCorrect = true;
                firstTime = true;
                prev_length++;
            }
            else
            {
                isCorrect = true;
            }
        }
    }


    //
    // 01234
    //
    public int getCurWordLength(String generatedText, int total_index){
        int count = 0;
        while(generatedText.charAt(total_index) != ' ') {
            count++;
            if(total_index == generatedText.length() - 1)
                return count;
            total_index++;
        }
        return count;
    }
}